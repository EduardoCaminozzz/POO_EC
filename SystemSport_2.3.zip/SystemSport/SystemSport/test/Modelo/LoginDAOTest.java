
package Modelo;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class LoginDAOTest {
    
    public LoginDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testLogInCorrecto() {
        LoginDAO loginDAO = new LoginDAO();
        login usuarioValido = loginDAO.log("edu@gmail.com", "123");
        assertNotNull(usuarioValido);
        assertEquals("edu@gmail.com", usuarioValido.getCorreo());
        assertEquals("123", usuarioValido.getPass());
    }
     @Test
    public void testLogInCorrecto_2() {
        LoginDAO loginDAO = new LoginDAO();
        login usuarioValido = loginDAO.log("ls@gmail.com", "321");
        assertNotNull(usuarioValido);
        assertEquals("ls@gmail.com", usuarioValido.getCorreo());
        assertEquals("321", usuarioValido.getPass());
    }

/*  @Test
    public void testLogInIncorrecto() {
        LoginDAO loginDAO = new LoginDAO();
        login usuarioInvalido = loginDAO.log("","");
        assertNull(usuarioInvalido);
        
    }
 */   
}
