
package systemsport;

import Vista.Login;

public class SystemSport {


    public static void main(String[] args) {
        Login log = new Login();
        log.setVisible(true);
        
    }
    
}
